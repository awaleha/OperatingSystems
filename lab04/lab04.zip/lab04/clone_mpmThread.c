//fork makes a second process, running the same executable
//pid_t used to be long, but now just int
#define _GNU_SOURCE  //for Ubuntu
#include <unistd.h>
#include <sched.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>

int x=0, y=0;
pid_t pid; 

int do_something() {
   int pid  = getpid();
   printf ("\nThis is process(thread) %d. \n",pid);
   x=7;
   printf("x+y=%d\n",x+y);
} 

int main ( void ) {
   const int STACK_SIZE = 65536;  //note stack grows down
   char *stack;
   char *stackTop;
   
   stack = malloc(STACK_SIZE);
   if (stack == NULL) {
       perror("malloc"); exit(1);
   }
   stackTop = stack + STACK_SIZE;

   y=1;
   int cret; 
   cret = clone(do_something, stackTop, CLONE_VM, NULL);
   if (cret==-1) {perror("clone"); exit(0); }
   pid  = getpid();
   printf ("\nThis is process(thread) %d.\n",pid);
   printf("x+y=%d\n",x+y);
}


